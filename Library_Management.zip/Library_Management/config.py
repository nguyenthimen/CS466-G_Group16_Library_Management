import os

class Config:
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'men1905@'
    MYSQL_DB = 'librarydb'
    SECRET_KEY = os.urandom(24)
