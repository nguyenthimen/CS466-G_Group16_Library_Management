// Hiding flash messages after 3 seconds
setTimeout(function() {
    const alert = document.querySelector('.alert');
    if (alert) {
        alert.style.display = 'none';
    }
}, 3000);

// Optionally, you can add more interactive features using JavaScript
