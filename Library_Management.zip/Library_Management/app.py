from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
import datetime
import logging

logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__, template_folder='templates')
app.config.from_object('config.Config')
app.secret_key = 'your_secret_key_here'  # Thêm khóa bí mật để sử dụng session

# Cấu hình kết nối MySQL
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'men1905@'
MYSQL_DB = 'librarydb'

mysql = MySQL(app)

@app.route('/')
def index():
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM Books")
        books = cursor.fetchall()
        cursor.close()
        return render_template('index.html', books=books)
    except Exception as e:
        logging.error(f"Error fetching books: {e}")
        return f"Error: {e}", 500

@app.route('/books', methods=['GET', 'POST'])
def books():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM Books")
    books = cursor.fetchall()
    cursor.close()
    return render_template('books.html', books=books)

@app.route('/search', methods=['GET', 'POST'])
def search():
    if not session.get('user_id'):  # Kiểm tra xem người dùng đã đăng nhập chưa
        flash('You need to log in to search books.', 'warning')
        return redirect(url_for('login'))  # Chuyển hướng tới trang login nếu chưa đăng nhập

    if request.method == 'POST':
        query = request.form['query']
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM Books WHERE title LIKE %s OR author LIKE %s", (f"%{query}%", f"%{query}%"))
        books = cursor.fetchall()
        cursor.close()
        return render_template('books.html', books=books, query=query)
    return render_template('search.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])

        try:
            cursor = mysql.connection.cursor()
            cursor.execute("INSERT INTO Users (name, email, password, role) VALUES (%s, %s, %s, 'member')", 
                           (name, email, password))
            mysql.connection.commit()
            cursor.close()
            
            flash('Registration successful! Please login.', 'success')
            logging.info('User registered successfully')
            return redirect(url_for('login'))
        except Exception as e:
            mysql.connection.rollback()
            flash(f'Error: {e}', 'danger')
            logging.error(f'Registration error: {e}')
            return render_template('register.html')

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT id, name, password FROM Users WHERE email=%s", (email,))
        user = cursor.fetchone()
        cursor.close()

        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            session['user_name'] = user[1]
            flash(f'Welcome, {user[1]}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid credentials. Please try again.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()  # Clear the session to log the user out
    flash('You have been logged out.', 'info')  # Flash a message to inform the user
    return redirect(url_for('index'))  # Redirect to the homepage after logout


@app.route('/borrow/<int:book_id>', methods=['POST'])
def borrow_book(book_id):
    if not session.get('user_id'):  # Kiểm tra nếu người dùng chưa đăng nhập
        flash('You need to log in to borrow books.', 'warning')
        return redirect(url_for('login'))  # Chuyển hướng đến trang login nếu chưa đăng nhập

    user_id = session.get('user_id')
    borrow_date = datetime.date.today()
    return_date = None

    try:
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO BorrowedBooks (user_id, book_id, borrow_date, return_date) VALUES (%s, %s, %s, %s)",
                       (user_id, book_id, borrow_date, return_date))
        cursor.execute("UPDATE Books SET status='borrowed' WHERE id=%s", (book_id,))
        mysql.connection.commit()
    except Exception as e:
        mysql.connection.rollback()
        logging.error(f"Error borrowing book: {e}")
        flash(f"Error: {e}", 'danger')
    finally:
        cursor.close()

    flash('Book borrowed successfully!', 'success')
    return redirect(url_for('books'))

@app.route('/return/<int:borrow_id>', methods=['POST'])
def return_book(borrow_id):
    if not session.get('user_id'):  # Kiểm tra nếu người dùng chưa đăng nhập
        flash('You need to log in to return books.', 'warning')
        return redirect(url_for('login'))  # Chuyển hướng đến trang login nếu chưa đăng nhập

    user_id = session.get('user_id')
    return_date = datetime.date.today()

    try:
        cursor = mysql.connection.cursor()

        # Retrieve the book_id
        cursor.execute("SELECT book_id FROM BorrowedBooks WHERE id=%s", (borrow_id,))
        result = cursor.fetchone()
        if not result:
            flash('Borrow record not found.', 'danger')
            return redirect(url_for('books'))

        book_id = result[0]

        # Update return_date in BorrowedBooks table
        cursor.execute("UPDATE BorrowedBooks SET return_date=%s WHERE id=%s", (return_date, borrow_id))
        
        # Update the status in Books table
        cursor.execute("UPDATE Books SET status='available' WHERE id=%s", (book_id,))
        
        mysql.connection.commit()
    except Exception as e:
        mysql.connection.rollback()
        logging.error(f"Error returning book: {e}")
        flash(f"Error: {e}", 'danger')
    finally:
        cursor.close()
        
    flash('Book returned successfully!', 'success')
    return redirect(url_for('books'))

@app.route('/update_status', methods=['POST'])
def update_status():
    data = request.get_json()
    book_id = data.get('book_id')
    new_status = data.get('new_status')
    
    try:
        cursor = mysql.connection.cursor()
        if new_status == "borrowed":
            cursor.execute("UPDATE Books SET status='borrowed' WHERE id=%s", (book_id,))
        elif new_status == "available":
            cursor.execute("UPDATE Books SET status='available' WHERE id=%s", (book_id,))
        mysql.connection.commit()
        cursor.close()
        return {"success": True, "new_status": new_status}, 200
    except Exception as e:
        mysql.connection.rollback()
        return {"success": False, "error": str(e)}, 500

if __name__ == '__main__':
     app.run(debug=True)
